package com.example.gmail

data class Email(
    val sender: String,
    val title: String,
    val description: String,
    val time: String
)
